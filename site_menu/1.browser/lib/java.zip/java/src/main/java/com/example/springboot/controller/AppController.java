package com.example.springboot.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

@RestController
public class AppController {

	@Value("${sconnector.accessKey}")
	private String accessKey;

	@Value("${sconnector.secretKey}")
	private String secretKey;


	@RequestMapping("/")
	public String index() {
		return "Greetings from Spring Boot!";
	}

	/**
	 * access token + secret token 기반으로 jwt 를 받아 옵니다.
	 * 보안적인 이슈로 server 에서 작업하시길 권장 드립니다.
	 * @return
	 */
	@RequestMapping("/auth")
	public Map getJwt() throws IOException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpPost postRequest = new HttpPost("https://api.interwater.biz/v1/auth");
		Map map = new HashMap<String, String>();
		map.put("accessKey", accessKey);
		map.put("secretKey", secretKey);
		Gson gson = new Gson();
		String json = gson.toJson(map);
		System.out.println("json : " + json);
		postRequest.addHeader("content-type", "application/json");
		postRequest.setEntity(new StringEntity(json));
		HttpResponse response = client.execute(postRequest);
		ResponseHandler<String> handler = new BasicResponseHandler();
		String body = handler.handleResponse(response);
		Map convertedObject = new Gson().fromJson(body, Map.class);
		System.out.println("res :" + convertedObject.toString());
		return convertedObject;
	}
	//
}
